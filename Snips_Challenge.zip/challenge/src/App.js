import React, { Component } from 'react';
import Grammars from "./Components/Grammars";
import DNDTestList from "./Components/DragAndDrop/DNDTestList";
import DNDTestList2 from "./Components/DragAndDrop/DNDTestList2";
import './App.css';


class App extends Component {
  constructor(){
    super();
    let data = require('./data.json');
    this.state = {
      title: [], //Used sometimes for testing instead of console.log
      grammars: data,
      current: data,
      locationArray: [],
      history: [[]],
      dragNdropTest: null,
//      breadCrumbs: this.breadCrumbs(),
    };

    this.handleClick = this.handleClick.bind(this);
    this.addColumn = this.addColumn.bind(this); //necessary so I don't have to give the parameters while transferring the function to the component
    this.addEntry = this.addEntry.bind(this);
  }

  breadCrumbs() {
    if (this.state.locationArray){
      let current = this.state.grammars;
      let navLevels = this.state.locationArray.map(coord => {
        let name = current[coord[0]][coord[1]].definition;
        current = current[coord[0]][coord[1]].possibleValues;
        return name
      });
      return (
        navLevels.map((level, index) => <button onClick={()=>this.goToLocation(index+1)} key={level}>{level}</button>)
      );
    }
    else {
      return;
    }
  }

  goToLocation(indexPlusOne){
      let newLocation = this.state.locationArray.slice(0, indexPlusOne);
      this.state.history.push(newLocation);
      this.refreshLocation(newLocation);
  }

  refreshLocation(locationArray) {
    let levels = [];
    let current = this.state.grammars; //reset
    locationArray.forEach(elm => {
      levels.push(current[elm[0]][elm[1]].definition);
      current = current[elm[0]][elm[1]].possibleValues;
     });
    this.setState({
        current, //new way for assigning the value, instead of repeating the variable
        levels: levels,
        locationArray,
    });
  }

  handleClick(loc) {
      let newLocation = this.state.locationArray.slice();
      newLocation.push(loc);
      this.state.history.push(newLocation);
      this.refreshLocation(newLocation);
  }

  goBack() {
    if (this.state.history.length>1) {
      this.state.history.pop();
      let newLocation = this.state.history.slice(-1)[0];
      this.refreshLocation(newLocation);
    }
  }

  addColumn(definition) {
    let current = this.state.current; //reset
    current.push(
      [{"definition": definition,
      "possibleValues": []
    }]);
    this.setState({
        current,
    });
  }

  addEntry(index, definition) {
    //console.log(index);
    let current = this.state.current; //reset
    current[index].push(
      {"definition": definition,
      "possibleValues": []
    });
    this.setState({
        current,
    });
  }

  callDragAndDrop() {
    this.setState({
      dragNdropTest: this.showDragAndDrop(),
    });
  }

  showDragAndDrop() {
    return(
      <div className="DNDLists">
        <DNDTestList2 />
      </div>
    );
  }

  render() {
    let navLevels = this.state.items;
    return(
    <div className="App">
       <div className="Test">
       <h2>{this.state.title}</h2>
       </div>
       <div className="breadCrumbs">
          <button onClick={()=>this.goToLocation(0)} id="startNav">/</button>
          {/*this.state.breadCrumbs*/}
          {this.breadCrumbs()}
          <button onClick={() => this.goBack() } id="gobackNav">BACK</button>
       </div>
       <br></br>
       <br></br>
       <Grammars
          onClick={this.handleClick}
          values={this.state.current}
          onNewColumn={this.addColumn}
          onAddEntryClick={this.addEntry}
       />
       <br></br>
       <br></br>
       {this.state.dragNdropTest}
       <br></br>
       <button onClick={() => this.callDragAndDrop() }>Drag and Drop</button>
    </div>
  )
  }
}

export default App;
