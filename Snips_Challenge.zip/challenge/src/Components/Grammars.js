import React, { Component } from 'react';
import GrammarColumn from './GrammarColumn';
import AddButton from './AddButton';

class Grammars extends Component {

  render() {
    let projectItems;
    if(this.props.values) {
      projectItems = this.props.values.map((project, index) => {
        return (
            <GrammarColumn x={index} onAddEntryClick={this.props.onAddEntryClick} onClick={this.props.onClick} key={project.definition} grammar={project} />
        );
      });
    }
    //<button onClick={this.props.onGrammarAddClick}> +++ </button>
    return (
      <div className="Projects">
        {projectItems}
        <AddButton onNewColumn={this.props.onNewColumn}  />
      </div>
    );
  }
}

export default Grammars;
