import React, { Component } from 'react';

class ItemDefinition extends Component {
  handleClick() {
    this.props.onClick('test');
  }

  render() {
    return (
          <button  onClick={() => this.props.onClick([this.props.x, this.props.y])} className="addButton">{this.props.def.definition}</button>
    );
  }
}

export default ItemDefinition;
