import React, { Component } from 'react';

class AddEntryButton extends Component {
  constructor(){
    super();
    this.state = {
      element: this.callButton(),
      newDefinition: null, //Why doesn't it work with guillemets???
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  callButton() {
    return (
      <button className="addEntry" onClick={() => this.callWidget()}>Add entry</button>
    );
  }

  callWidget() {
    this.setState(
      {element: this.widget()}
    )
  }

  widget(){
    return(
      <div className="widget">
      <input type="text" value={this.state.newDefinition} onChange={this.handleChange} placeholder="Entry name"></input>
      <button className="confirmDef" onClick={this.handleSubmit}>ok</button>
      </div>
    )
  }

  handleChange(event){
    this.setState(
      {newDefinition: event.target.value}
    );
  }

  handleSubmit() {
    //console.log(this.state.newDefinition);
    if (this.state.newDefinition) {
      this.props.onNewEntry(this.props.index, this.state.newDefinition);
      this.setState({
        element : this.callButton(),
        newDefinition : null,
        type: null,
      });
    }
  }

  render() {
  //  <button onClick={() => this.props.onClick()}>+++</button>
    return (
        <div>
          {this.state.element}
        </div>
    );
  }
}

export default AddEntryButton;
