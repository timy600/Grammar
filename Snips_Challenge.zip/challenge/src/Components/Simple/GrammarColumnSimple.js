import React, { Component } from 'react';
import ItemDefinition from './ItemDefinitionSimple';

class GrammarColumn extends Component {
  render() {
    let valuesDefs;
    if(this.props.grammar.possibleValues) {
      valuesDefs = this.props.grammar.possibleValues.map(value => {
        return (
            <ItemDefinition key={value} def={value} />
        );
      });
    }
    return (
        <div className="possibleValues">
          <button>{this.props.grammar.definition}</button>
          <div className="ItemDefinition">
            {valuesDefs}
          </div>
          <div className="addButton">
            <button> + </button>
          </div>
        </div>
    );
  }
}

export default GrammarColumn;
