import React, { Component } from 'react';
import GrammarColumn from './GrammarColumnSimple';

class Grammars extends Component {
  render() {
    let projectItems;
    if(this.props.values) {
      projectItems = this.props.values.map(project => {
        return (
            <GrammarColumn key={project.definition} grammar={project} />
        );
      });
    }
    return (
      <div className="Projects">
        {projectItems}
        <button onClick={this.props.onClick}> +++ </button>
      </div>
    );
  }
}

export default Grammars;
