import React, { Component } from 'react';

class ItemDefinition extends Component {
  render() {
    return (
          <button className="addButton">{this.props.def.definition}</button>
    );
  }
}

export default ItemDefinition;
