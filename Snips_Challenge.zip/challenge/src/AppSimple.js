import React, { Component } from 'react';
import Grammars from "./Components/Simple/GrammarsSimple";
import './App.css';

class App extends Component {
  constructor(){
    super();
    this.state = {
      title: 0,
      grammarLevel: require('./dataSimple.json'),
    };
  }

  handleClick() {
    this.setState({
      title: this.state.title+1,
    });
  }

  render() {
    return(
    <div className="App">
       <h1>Level: {this.state.title}</h1>
       <Grammars
          values={this.state.grammarLevel[0].possibleValues}
          onClick={() => this.handleClick()}
       />
    </div>
  )
  }
}

export default App;
